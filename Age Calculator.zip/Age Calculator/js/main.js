
// Light | Dark Mood Switcher
var body = document.body;
body.style.backgroundColor = 'rgb(245, 245, 245)';
body.ondblclick = function(){
  if(body.style.backgroundColor == 'rgb(245, 245, 245)'){
    body.style.backgroundColor = 'rgb(70, 70, 70)';
  }else{
    body.style.backgroundColor = 'rgb(245, 245, 245)';
  }
}
function AgeCalc() {
  // Get User Birthday detailes
  var birthDay = document.getElementById("day").value;
  var birthMonth = document.getElementById("month").value;
  var birthYear = document.getElementById("year").value;
  // Get Today Date
  var date = new Date();
  var currentDay = date.getDate();
  var currentMonth = date.getMonth() + 1;
  var currentYear = date.getFullYear();
  var currentHour = date.getHours();
  var currentMinutes = date.getMinutes();
  var currentSecondes = date.getSeconds();
  // Calc Years
  var years = currentYear - birthYear;
  // Calc Months
  var months = currentMonth - birthMonth;
  if (months < 0) {
    years -= 1;
    months += 12;
  }
  // Get Total Days on This Month
  var monthDays = 31; // Most Months Days
  // Calc Total Days in February
  if (currentMonth == 2) {
    if (currentYear % 4 == 0) {
      monthDays = 29
    } else {
      monthDays = 28;
    }
  }
  // Months With 30day
  if (currentMonth == (4 || 6 || 9 || 11)) {
    monthDays = 30;
  }
  // Calc Days
  var days = currentDay - birthDay;
  if (days < 0) {
    months -= 1;
    if (months < 0) {
      years -= 1;
      months += 12;
    }
    days += monthDays;
  }
  // Calc More Information About Birthday
  var totalMonths = years * 12 + months;
  var totalDays = totalMonths * monthDays + days;
  var totalweeks = Math.floor(totalDays / 7);
  var totalHours = totalDays * 24 + currentHour;
  var totalMinutes = totalHours * 60 + currentMinutes;
  var totalSecondes = totalMinutes * 60 + currentSecondes;

  // Define Location where infos will be written
  var agePointer = document.getElementById('age');
  var monthsPointer = document.getElementById('months');
  var weeksPointer = document.getElementById('weeks');
  var daysPointer = document.getElementById('days');
  var hoursPointer = document.getElementById('hours');
  var minutesPointer = document.getElementById('minutes');
  var secondesPointer = document.getElementById('secondes');
  var nextBirthdayPointer = document.getElementById('next-birthday');

  // Write Age 
  if (years != 0) {
    agePointer.innerText = years + ' year';
  }
  if (months != 0) {
    agePointer.innerText += ' & ' + months + ' month';
  }
  if (days != 0) {
    agePointer.innerText += ' & ' + days + ' day';
  }
  // Calc Next Birthday

  var nextBirthMonth = birthMonth - currentMonth;
  var nextBirthDay = birthDay - currentDay;

  if (nextBirthDay < 0) {
    nextBirthMonth -= 1;
    nextBirthDay += monthDays;
  }
  if (nextBirthMonth < 0) {
    nextBirthMonth += 12;
  }
  // Get Day Name of Next Birthday
  var nextDate = (birthMonth + '/' + birthDay + '/' + (currentYear + 1)).toString();
  var dayName = new Date(nextDate);
  dayName = dayName.getDay();
  switch (dayName) {
    case 0:
      dayName = 'Sunday';
      break;
    case 1:
      dayName = 'Monday';
      break;
    case 2:
      dayName = 'Tuesday';
      break;
    case 3:
      dayName = 'Wednesday';
      break;
    case 4:
      dayName = 'Thusrday';
      break;
    case 5:
      dayName = 'Friday';
      break;
    case 6:
      dayName = 'Saturday';
      break;
    default:
      break;
  }

  // Write Total Birthday Info
  monthsPointer.innerText = totalMonths + ' Month';
  weeksPointer.innerText = totalweeks + ' Week';
  daysPointer.innerText = totalDays + ' Day';
  hoursPointer.innerText = totalHours + ' Hour';
  minutesPointer.innerText = totalMinutes + ' Minute';
  secondesPointer.innerText = totalSecondes + ' Seconde';

  // Write Next Birthday Output
  nextBirthdayPointer.innerText = ' ' + dayName + ' after';
  if (nextBirthMonth != 0) {
    nextBirthdayPointer.innerText += ' ' + nextBirthMonth + ' Month';
  }
  if (nextBirthDay != 0) {
    nextBirthdayPointer.innerText += ' ,' + nextBirthDay + ' Day';
  }
}
